import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getAllHosts = async (req, res) => {
  try {
    const hosts = await prisma.host.findMany();
    res.json(hosts);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching hosts" });
  }
};

export const createHost = async (req, res) => {
  try {
    const {
      username,
      password,
      name,
      email,
      phoneNumber,
      profilePicture,
      aboutMe,
    } = req.body;
    const newHost = await prisma.host.create({
      data: {
        username,
        password,
        name,
        email,
        phoneNumber,
        profilePicture,
        aboutMe,
      },
    });
    res.status(201).json(newHost);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while creating host" });
  }
};

export const getHostById = async (req, res) => {
  try {
    const { id } = req.params;
    const host = await prisma.host.findUnique({ where: { id } });
    if (host) {
      res.json(host);
    } else {
      res.status(404).json({ error: "Host not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching host" });
  }
};

export const updateHost = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      username,
      password,
      name,
      email,
      phoneNumber,
      profilePicture,
      aboutMe,
    } = req.body;
    const updatedHost = await prisma.host.update({
      where: { id },
      data: {
        username,
        password,
        name,
        email,
        phoneNumber,
        profilePicture,
        aboutMe,
      },
    });
    res.json(updatedHost);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while updating host" });
  }
};

export const deleteHost = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.host.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "An error occurred while deleting host" });
  }
};

export const searchHosts = async (req, res) => {
  try {
    const { name } = req.query;
    const filters = {};
    if (name) filters.name = { contains: name };
    const hosts = await prisma.host.findMany({ where: filters });
    if (hosts.length === 0) {
      res.status(404).json({ error: "Host not found" });
    } else {
      res.json(hosts);
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while searching hosts" });
  }
};
