import pkg from "@prisma/client";
const { PrismaClient } = pkg;
const prisma = new PrismaClient();

export const getAllBookings = async (req, res) => {
  try {
    const bookings = await prisma.booking.findMany();
    res.json(bookings);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching bookings" });
  }
};

export const createBooking = async (req, res) => {
  try {
    const {
      checkinDate,
      checkoutDate,
      numberOfGuests,
      totalPrice,
      bookingStatus,
      userId,
      propertyId,
    } = req.body;
    const newBooking = await prisma.booking.create({
      data: {
        checkinDate,
        checkoutDate,
        numberOfGuests,
        totalPrice,
        bookingStatus,
        userId,
        propertyId,
      },
    });
    res.status(201).json(newBooking);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while creating booking" });
  }
};

export const getBookingById = async (req, res) => {
  try {
    const { id } = req.params;
    const booking = await prisma.booking.findUnique({ where: { id } });
    if (booking) {
      res.json(booking);
    } else {
      res.status(404).json({ error: "Booking not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching booking" });
  }
};

export const updateBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      checkinDate,
      checkoutDate,
      numberOfGuests,
      totalPrice,
      bookingStatus,
      userId,
      propertyId,
    } = req.body;
    const updatedBooking = await prisma.booking.update({
      where: { id },
      data: {
        checkinDate,
        checkoutDate,
        numberOfGuests,
        totalPrice,
        bookingStatus,
        userId,
        propertyId,
      },
    });
    res.json(updatedBooking);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while updating booking" });
  }
};

export const deleteBooking = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.booking.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "An error occurred while deleting booking" });
  }
};

export const searchBookings = async (req, res) => {
  try {
    const { userId, propertyId } = req.query;
    const filters = {};

    if (userId) filters.userId = { contains: userId };
    if (propertyId) filters.propertyId = { contains: propertyId };

    const bookings = await prisma.booking.findMany({
      where: filters,
    });

    if (bookings.length === 0) {
      res.status(404).json({ error: "Booking not found" });
    } else {
      res.json(bookings);
    }
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while searching bookings" });
  }
};
