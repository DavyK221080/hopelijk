import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getAllUsers = async (req, res) => {
  try {
    const users = await prisma.user.findMany();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching users" });
  }
};

export const createUser = async (req, res) => {
  try {
    const { username, password, name, email, phoneNumber, profilePicture } =
      req.body;
    const newUser = await prisma.user.create({
      data: { username, password, name, email, phoneNumber, profilePicture },
    });
    res.status(201).json(newUser);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while creating user" });
  }
};

export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await prisma.user.findUnique({ where: { id } });
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching user" });
  }
};

export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { username, password, name, email, phoneNumber, profilePicture } =
      req.body;
    const updatedUser = await prisma.user.update({
      where: { id },
      data: { username, password, name, email, phoneNumber, profilePicture },
    });
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while updating user" });
  }
};

export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.user.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "An error occurred while deleting user" });
  }
};

export const searchUsers = async (req, res) => {
  try {
    const { username, email } = req.query;
    const filters = {};
    if (username) filters.username = { contains: username };
    if (email) filters.email = { contains: email };
    const users = await prisma.user.findMany({ where: filters });
    if (users.length === 0) {
      res.status(404).json({ error: "User not found" });
    } else {
      res.json(users);
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while searching users" });
  }
};
