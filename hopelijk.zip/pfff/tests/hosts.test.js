import request from "supertest";
import app from "../index.js";

let token;

beforeAll(async () => {
  const response = await request(app).post("/auth/login").send({
    email: "johndoe@example.com",
    password: "password123",
  });
  token = response.body.token;
});

describe("Hosts API", () => {
  it("should return all hosts", async () => {
    const response = await request(app)
      .get("/hosts")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeInstanceOf(Array);
    expect(response.body.length).toBeGreaterThan(0);
  });

  it("should return host by ID", async () => {
    const response = await request(app)
      .get("/hosts/f1234567-89ab-cdef-0123-456789abcdef")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toHaveProperty(
      "id",
      "f1234567-89ab-cdef-0123-456789abcdef"
    );
  });

  it("should return 404 for non-existing host", async () => {
    const response = await request(app)
      .get("/hosts/non-existing-id")
      .set("Authorization", `Bearer ${token}`)
      .expect(404);

    expect(response.body).toHaveProperty("error", "Host not found");
  });
});
