import request from "supertest";
import app from "../index.js";

let token;

beforeAll(async () => {
  const response = await request(app).post("/auth/login").send({
    email: "johndoe@example.com",
    password: "password123",
  });
  token = response.body.token;
});

describe("Properties API", () => {
  it("should return all properties", async () => {
    const response = await request(app)
      .get("/properties")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeInstanceOf(Array);
    expect(response.body.length).toBeGreaterThan(0);
  });

  it("should return property by ID", async () => {
    const response = await request(app)
      .get("/properties/g9012345-67ef-0123-4567-89abcdef0123")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toHaveProperty(
      "id",
      "g9012345-67ef-0123-4567-89abcdef0123"
    );
  });

  it("should return 404 for non-existing property", async () => {
    const response = await request(app)
      .get("/properties/non-existing-id")
      .set("Authorization", `Bearer ${token}`)
      .expect(404);

    expect(response.body).toHaveProperty("error", "Property not found");
  });
});
