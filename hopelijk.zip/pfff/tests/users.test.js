import request from "supertest";
import app from "../index";

describe("Users API", () => {
  let token;

  beforeAll(async () => {
    const response = await request(app).post("/auth/login").send({
      email: "johndoe@example.com",
      password: "password123",
    });
    token = response.body.token;
  });

  it("should return a list of users", async () => {
    const response = await request(app)
      .get("/users")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeInstanceOf(Array);
    expect(response.body.length).toBeGreaterThan(0);

    const user = response.body.find(
      (user) => user.email === "johndoe@example.com"
    );
    expect(user).toBeDefined();
    expect(user.email).toBe("johndoe@example.com");
  });

  it("should return a user by ID", async () => {
    const response = await request(app)
      .get("/users/a1234567-89ab-cdef-0123-456789abcdef")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeDefined();
    expect(response.body.email).toBe("johndoe@example.com");
  });

  it("should return 404 for non-existing user", async () => {
    await request(app)
      .get("/users/non-existing-id")
      .set("Authorization", `Bearer ${token}`)
      .expect(404);
  });
});
