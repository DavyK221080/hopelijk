import request from "supertest";
import app from "../index.js";

let server;

beforeAll(async () => {
  server = app.listen(0);
});

afterAll(async () => {
  await server.close();
});

describe("POST /auth/login", () => {
  it("should return 200 and a token for valid credentials", async () => {
    const response = await request(server)
      .post("/auth/login")
      .send({ email: "johndoe@example.com", password: "password123" });

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("token");
  });

  it("should return 400 for invalid credentials", async () => {
    const response = await request(server)
      .post("/auth/login")
      .send({ email: "johndoe@example.com", password: "wrongpassword" });

    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty("error", "Invalid email or password");
  });
});
