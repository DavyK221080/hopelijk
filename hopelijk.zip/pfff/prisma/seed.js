import { PrismaClient } from "@prisma/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const prisma = new PrismaClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const seedUsers = async () => {
  const dataPath = path.join(__dirname, "../data/users.json");
  const usersData = JSON.parse(fs.readFileSync(dataPath, "utf8")).users;
  for (const user of usersData) {
    const existingUser = await prisma.user.findUnique({
      where: { email: user.email },
    });
    if (!existingUser) {
      await prisma.user.create({ data: user });
    } else {
      console.log(`User with email ${user.email} already exists. Skipping.`);
    }
  }
};

const seedHosts = async () => {
  const dataPath = path.join(__dirname, "../data/hosts.json");
  const hostsData = JSON.parse(fs.readFileSync(dataPath, "utf8")).hosts;
  for (const host of hostsData) {
    const existingHost = await prisma.host.findUnique({
      where: { email: host.email },
    });
    if (!existingHost) {
      await prisma.host.create({ data: host });
    } else {
      console.log(`Host with email ${host.email} already exists. Skipping.`);
    }
  }
};

const seedProperties = async () => {
  const dataPath = path.join(__dirname, "../data/properties.json");
  const propertiesData = JSON.parse(
    fs.readFileSync(dataPath, "utf8")
  ).properties;
  for (const property of propertiesData) {
    await prisma.property.create({ data: property });
  }
};

const seedBookings = async () => {
  const dataPath = path.join(__dirname, "../data/bookings.json");
  const bookingsData = JSON.parse(fs.readFileSync(dataPath, "utf8")).bookings;
  for (const booking of bookingsData) {
    await prisma.booking.create({ data: booking });
  }
};

const seedAmenities = async () => {
  const dataPath = path.join(__dirname, "../data/amenities.json");
  const amenitiesData = JSON.parse(fs.readFileSync(dataPath, "utf8")).amenities;
  for (const amenity of amenitiesData) {
    await prisma.amenity.create({ data: amenity });
  }
};

const seedReviews = async () => {
  const dataPath = path.join(__dirname, "../data/reviews.json");
  const reviewsData = JSON.parse(fs.readFileSync(dataPath, "utf8")).reviews;
  for (const review of reviewsData) {
    await prisma.review.create({ data: review });
  }
};

const main = async () => {
  try {
    await seedUsers();
    await seedHosts();
    await seedProperties();
    await seedBookings();
    await seedAmenities();
    await seedReviews();
    console.log("All data seeded successfully.");
  } catch (e) {
    console.error("Error seeding data:", e);
  } finally {
    await prisma.$disconnect();
  }
};

main();
