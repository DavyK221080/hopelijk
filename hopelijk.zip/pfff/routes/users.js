import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllUsers,
  createUser,
  getUserById,
  updateUser,
  deleteUser,
  searchUsers,
} from "../services/userService.js";

const router = express.Router();

router.get("/", authenticate, getAllUsers);
router.post("/", authenticate, createUser);
router.get("/search", authenticate, searchUsers);
router.get("/:id", authenticate, getUserById);
router.put("/:id", authenticate, updateUser);
router.delete("/:id", authenticate, deleteUser);

export default router;
